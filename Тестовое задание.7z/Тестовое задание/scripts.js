const openPopUp = document.getElementById('open_pop_up');
const closePopUp = document.getElementById('pop_up_close');
const popUp = document.getElementById('pop_up');



// function ClearForm() {
// 	document.getElementById('email').value = '';
// 	document.getElementById('name').value = '';
// 	document.getElementById('surname').value = '';
// 	document.getElementById('password').value = '';
// 	document.getElementById('repeat_password').value = '';
// }

function PostForm() {

	var x = true;

	if (document.getElementById('email').value.length > 0) {

		if (document.getElementById('email').value.indexOf('@') == -1) {
			alert('E-mail введен некорректно!');
			x = false;
		}

	} else {

		alert('Поле E-mail пустое!');
		x = false;

	};


	if (document.getElementById('name').value == '') {
		alert('Поле "Имя" не заполнено!');
		x = false;
	};


	if (document.getElementById('surname').value == '') {
		alert('Поле "Фамилия" не заполнено!');
		x = false;
	};


	if(document.getElementById('password').value == '') {
		alert('Поле "Пароль" не заполнено!');
		x = false;
	}


	if(document.getElementById('repeat_password').value == '') {
		alert('Поле "Подтвердите пароль" не заполнено!');
		x = false;
	}


	if(document.getElementById('password').value != document.getElementById('repeat_password').value){
		alert('Пароли должны совпадать');
		x = false;
	}

	if (x == true){
		openPopUp.addEventListener('click', function(e){
			e.preventDefault();
			popUp.classList.add('active');
		})

		closePopUp.addEventListener('click', () => {
			popUp.classList.remove('active');
		})
	}

};